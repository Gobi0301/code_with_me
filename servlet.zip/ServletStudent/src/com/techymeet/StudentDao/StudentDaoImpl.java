package com.techymeet.StudentDao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.techymeet.StudentBo.LoginBO;
import com.techymeet.StudentBo.StudentBO;
import com.techymeet.StudentDb.DatabaseConnection;

public class StudentDaoImpl implements StudentDao{

	DatabaseConnection db  =new DatabaseConnection();
	@Override
	public int createStudent(StudentBO studentBo) {
		// TODO Auto-generated method stub
		int status = 0;
		try {
			Connection con = db.getConnection();
			String query = "insert into student (student_id,student_name,password,mobile_no,location) values (?,?,?,?,?)";
			PreparedStatement ps  = con.prepareStatement(query);
			ps.setInt(1, studentBo.getStudentId());
			ps.setString(2, studentBo.getStudentName());
			ps.setString(3,studentBo.getPassword());
			ps.setLong(4, studentBo.getMobileNo());
			ps.setString(5, studentBo.getLocation());
			 status =  ps.executeUpdate();
			  con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public int updateStudent(StudentBO studentBo) {
		// TODO Auto-generated method stub
		int status =0;
		try {
			Connection con=db.getConnection();
			String    sql       = "update student set student_id=?,student_name=?,password=?,mobile_no=?,location=? where student_id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, studentBo.getStudentId());
			ps.setString(2, studentBo.getStudentName());
			ps.setString(3, studentBo.getPassword());
			ps.setLong(4, studentBo.getMobileNo());
			ps.setString(5, studentBo.getLocation());
			ps.setInt(6, studentBo.getStudentId());
			status = ps.executeUpdate();
			con.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public int delete(int studentId) {
		// TODO Auto-generated method stub
		int id = 0;
	try {
			Connection con = db.getConnection();
		
			String    sql       = "Delete from student where student_id = ? ";
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, studentId);
			id = st.executeUpdate();
			st.close();
			con.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}
	@Override
	public StudentBO getStudent(int studentId) {
		// TODO Auto-generated method stub
		StudentBO res = null;
		try {
			Connection con=db.getConnection();
			Statement st = con.createStatement();
			String    query      = "select * from student where student_id="+studentId;
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				res = new StudentBO();
				res.setStudentId(rs.getInt("student_id"));
				res.setStudentName(rs.getString("student_name"));
				res.setPassword(rs.getString("password"));
				res.setMobileNo(rs.getLong("mobile_no"));
				res.setLocation(rs.getString("location"));
			}
			st.close();
			con.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	@Override
	public List<StudentBO> getAllStudents() {
		// TODO Auto-generated method stub
		StudentBO res = null;
		List<StudentBO> studentList = new ArrayList<StudentBO>();
		try {
			Connection con = db.getConnection();
			Statement st = con.createStatement();
			String query = "select * from student";
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				res = new StudentBO();
				res.setStudentId(rs.getInt(1));
				res.setStudentName(rs.getString(2));
				res.setPassword(rs.getString(3));
				res.setMobileNo(rs.getLong(4));
				res.setLocation(rs.getString(5));
				studentList.add(res);
			}
			st.close();
			con.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return studentList;
	}
	@Override
	public StudentBO login(LoginBO login) {
		// TODO Auto-generated method stub
		StudentBO response=null;
		try {
			Connection con=db.getConnection();
			Statement statement = con.createStatement();
			String    sql       = "select * from student where student_name='"+login.getUserName()+"' and password='"+login.getPassword()+"'";
			ResultSet rs=statement.executeQuery(sql);
			while(rs.next()) {
				response=new StudentBO();
				response.setStudentId(rs.getInt("student_id"));
				response.setStudentName(rs.getString("student_name"));
				response.setPassword(rs.getString("password"));
			}
			statement.close();
			con.close(); //closing connection
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		return response;
		
		
	}
	@Override
	public int login1(LoginBO user) {
		// TODO Auto-generated method stub
	int status = 0;
		try {
			Connection con = db.getConnection();
			String query = "insert into login username,password values ?,?,?";
			PreparedStatement ps  = con.prepareStatement(query);
			ps.setString(1, user.getUserName());
			ps.setString(2,user.getPassword());
			status = ps.executeUpdate();
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		
	}
		return status;
	}
}
