package com.techymeet.StudentDao;

import java.util.List;

import com.techymeet.StudentBo.LoginBO;
import com.techymeet.StudentBo.StudentBO;

public interface StudentDao {

	public  StudentBO login(LoginBO login);
	public int createStudent(StudentBO studentBo);
    public int  updateStudent(StudentBO studentBo);
	public int delete(int studentId);
	public StudentBO getStudent(int studentId);
    public List<StudentBO> getAllStudents();
    public int login1(LoginBO user);
}
	