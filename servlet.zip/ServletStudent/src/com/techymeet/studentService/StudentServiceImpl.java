package com.techymeet.studentService;

import java.util.List;

import com.techymeet.StudentBo.LoginBO;
import com.techymeet.StudentBo.StudentBO;
import com.techymeet.StudentDao.StudentDao;
import com.techymeet.StudentDao.StudentDaoImpl;


public class StudentServiceImpl implements StudentService{

	StudentDao student = new StudentDaoImpl();
	@Override
	public void createStudent(StudentBO studentBo) {
		// TODO Auto-generated method stub
 int status = 	student.createStudent(studentBo);
	if(0 < status) {
		System.out.println("Student Has Been Created Sucessfully!");
		}
		else {
			System.out.println("Student Creation failed");
		}
	
	}
	@Override
	public StudentBO getStudent(int studentId) {
		// TODO Auto-generated method stub
		return student.getStudent(studentId);
	}
	@Override
	public int deleteStudent(int studentId) {
		// TODO Auto-generated method stub
		return student.delete(studentId);
	}
	@Override
	public int updateStudent(StudentBO studentBo) {
		// TODO Auto-generated method stub
		return student.updateStudent(studentBo) ;
	}
	@Override
	public List<StudentBO> searchStudent() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<StudentBO> getAllStudents() {
		// TODO Auto-generated method stub
		List<StudentBO> studentist = student.getAllStudents();
		return studentist;
	}
	@Override
	public StudentBO login(LoginBO login) {
		// TODO Auto-generated method stub
		return student.login(login);
	}
	@Override
	public int login1(LoginBO user) {
		// TODO Auto-generated method stub
		return student.login1(user);
	}

}
