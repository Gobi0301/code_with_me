package com.techymeet.studentService;

import java.util.List;

import com.techymeet.StudentBo.LoginBO;
import com.techymeet.StudentBo.StudentBO;

public interface StudentService {
	public void createStudent(StudentBO studentBo);
	public StudentBO getStudent(int studentId);	
	public int deleteStudent(int studentId);
	public int updateStudent(StudentBO studentBo);
	public List<StudentBO> searchStudent();
	public List<StudentBO> getAllStudents();
	public StudentBO login(LoginBO login);
	public int login1(LoginBO user);
}
