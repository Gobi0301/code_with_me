package com.techymeet.Studentcontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techymeet.StudentBo.StudentBO;
import com.techymeet.studentService.StudentService;
import com.techymeet.studentService.StudentServiceImpl;

/**
 * Servlet implementation class EditStudent
 */
@WebServlet("/EditStudent")
public class EditStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	StudentService studentService=new StudentServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
		HttpSession session=request.getSession();
        PrintWriter out=response.getWriter();  
        if(null!=session.getAttribute("loggedInUser")) {
        out.println("<h1>Update Employee</h1>");  
        int studentId=new Integer(request.getParameter("id"));
		session.setAttribute("studentId",studentId);
		StudentBO student=studentService.getStudent(studentId);
        
		out.print("<form action='EditStudent' method='post'>");  
        out.print("<table>");  
        out.print("<tr><td></td><td><input type='hidden' name='id' value='"+student.getStudentId()+"'/></td></tr>");  
        out.print("<tr><td>Name:</td><td><input type='text' name='studentName' value='"+student.getStudentName()+"'/></td></tr>");
        out.print("<tr><td>Password:</td><td><input type='password' name='password' value='"+student.getPassword()+"'/></td></tr>"); 
        out.print("<tr><td>MobileNo:</td><td><input type='text' name='mobileNo' value='"+student.getMobileNo()+"'/></td></tr>"); 
        out.print("<tr><td>Loaction:</td><td><input type='text' name='location' value='"+student.getLocation()+"'/></td></tr>");
        out.print("<tr><td colspan='2'><input type='submit' value='Edit&save'/></td></tr>");  
        out.print("</table>");  
        out.print("</form>");  
        out.close();
      	}
        else {
			RequestDispatcher dispatch=request.getRequestDispatcher("/login.html");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession session=request.getSession();
		int StudentId=new Integer(session.getAttribute("studentId").toString());
		StudentBO student=new StudentBO();	
		student.setStudentId(StudentId);
		String studentName=request.getParameter("studentName");
		student.setStudentName(studentName);
		String password = request.getParameter("password");
		student.setPassword(password);
		String mobileNo=request.getParameter("mobileNo");
		student.setMobileNo(new Long(mobileNo));
		String location = request.getParameter("location");
		student.setLocation(location);
		StudentService studentService=new StudentServiceImpl();
		try {
			studentService.updateStudent(student);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("Student Updated successfully!");
		out.close();
		RequestDispatcher dispatch=request.getRequestDispatcher("/HomeServlet");
		dispatch.forward(request, response);
	}

}
