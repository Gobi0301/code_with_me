package com.techymeet.Studentcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techymeet.StudentBo.StudentBO;
import com.techymeet.studentService.StudentService;
import com.techymeet.studentService.StudentServiceImpl;

/**
 * Servlet implementation class CreateStudent
 */
@WebServlet("/CreateStudent")
public class CreateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public CreateStudent() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("called");
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		if(null!=session.getAttribute("loggedInUser")) {
		  out.println("<a href='form.html'>Add new student</a>");  
	        out.println("<h1>Student List</h1>");  
		StudentService studentService = new StudentServiceImpl();

			List<StudentBO> studentList = studentService.getAllStudents();

		/*	if (null != studentList && 0 < studentList.size()) {
				request.setAttribute("studentList", studentList);

				RequestDispatcher dispatch = request.getRequestDispatcher("list.html");
				dispatch.forward(request, response);
			} else {
				request.setAttribute("errorMessage", "No Record Found!");

				RequestDispatcher dispatch = request.getRequestDispatcher("list.html");
				dispatch.forward(request, response);
			}
			
		*/
			
			   out.print("<table border='1' width='50%'");  
			   out.print("<tr><th>studentId</th><th>studentName</th><th>Password</th><th>mobileNo</th><th>location</th> <th>Edit</th><th>Delete</th><th>View</th></tr>");  
		for(StudentBO student:studentList) {
			 out.print("<tr><td>"+student.getStudentId()+
					 "</td><td>"+student.getStudentName()+
					 "</td><td>"+student.getPassword()+
					 "</td><td>"+student.getMobileNo()+
					 "</td><td>"+student.getLocation()+
					 "</td><td><a href='EditStudent?id="+student.getStudentId()+
					 "'>edit</a></td><td><a href='DeleteStudent?id="+student.getStudentId()+"'>delete</a></td>"
					 		+ "<td><a href='viewStudent?id=\"+student.getStudentId()+\"'>view</a></td></tr>");  
	        }  
	     out.print("</table>");  
	     out.close();
	     out.println("<a href='HomeServlet'>Go To Home </a>");
	     
	}
		else {
			RequestDispatcher dispatch=request.getRequestDispatcher("/login.html");
			dispatch.forward(request, response);
		}
	}	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		StudentBO studentBo=new StudentBO();
		String studentId = request.getParameter("studentId");
		studentBo.setStudentId(Integer.parseInt(studentId));
		String studentName = request.getParameter("studentName");
		studentBo.setStudentName(studentName);
		String password = request.getParameter("password");
		studentBo.setPassword(password);
		String mobileNo = request.getParameter("mobileNo");
		studentBo.setMobileNo(Long.parseLong(mobileNo));
		String location = request.getParameter("location");
		studentBo.setLocation(location);
		StudentService studentService=new StudentServiceImpl();
		
		try {
			studentService.createStudent(studentBo);
		}catch(Exception e) {
			e.printStackTrace();
		}
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		pw.println("Student Created Successfully....!");
		pw.println("<a href='HomeServlet'>GoTo Home</a>");
	}

}
