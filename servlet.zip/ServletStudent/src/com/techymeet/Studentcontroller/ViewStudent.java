package com.techymeet.Studentcontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techymeet.StudentBo.StudentBO;
import com.techymeet.studentService.StudentService;
import com.techymeet.studentService.StudentServiceImpl;

/**
 * Servlet implementation class ViewStudent
 */
@WebServlet("/ViewStudent")
public class ViewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out = response.getWriter();
	StudentService student = new StudentServiceImpl();
	StudentBO studentBo = new StudentBO();
	String studentid = request.getParameter("id");
	int id = Integer.parseInt(studentid);
	studentBo = student.getStudent(id);
	 out.println("<h1>View Student</h1>"); 
     out.println("</br>");
	 out.print("<table border='1' width='100%'");  
     out.print("<tr><th>studentId</th><th>studentName</th><th>Password</th><th>mobileNo</th><th>location</th></tr>"); 
     out.print("<tr><td>"+studentBo.getStudentId()+"</td><td>"+studentBo.getStudentName()+"</td><td>"+studentBo.getPassword()+"</td><td>"+studentBo.getMobileNo()+"</td><td>"+studentBo.getLocation()+"</td></tr>");  
     out.print("</table>");  
     out.close();  

     /**/
     
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
