package com.techymeet.Studentcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techymeet.StudentBo.StudentBO;
import com.techymeet.studentService.StudentService;
import com.techymeet.studentService.StudentServiceImpl;

/**
 * Servlet implementation class StudentListValue
 */
@WebServlet("/StudentListValue")
public class StudentListValue extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentListValue() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		if(null!=session.getAttribute("loggedInUser")) {
		  out.println("<a href='form.html'>Add new student</a>");  
	        out.println("<h1>Student List</h1>");  
		StudentService studentService = new StudentServiceImpl();
			List<StudentBO> studentList = studentService.getAllStudents();
			   out.print("<table border='1' width='50%'");  
			   out.print("<tr><th>studentId</th><th>studentName</th><th>Password</th><th>mobileNo</th><th>location</th> <th>Edit</th><th>Delete</th><th>View</th></tr>");  
		for(StudentBO student:studentList) {
			 out.print("<tr><td>"+student.getStudentId()+
					 "</td><td>"+student.getStudentName()+
					 "</td><td>"+student.getPassword()+
					 "</td><td>"+student.getMobileNo()+
					 "</td><td>"+student.getLocation()+
					 "</td><td><a href='EditStudent?id="+student.getStudentId()+
					 "'>edit</a></td><td><a href='DeleteServlet?id="+student.getStudentId()+"'>delete</a></td>"+ "<td><a href='ViewStudent?id="+student.getStudentId()+"'>view</a></td></tr>");  

	        }  
	     out.print("</table>");  
	     out.close();
	     out.println("<a href='HomeServlet'>Go To Home </a>");
	     
	}
		else {
			RequestDispatcher dispatch=request.getRequestDispatcher("/login.html");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
