package com.techymeet.studentService;

import java.util.List;

import com.techymeet.studentBO.LoginBO;
import com.techymeet.studentBO.StudentBO;

public interface StudentService {

	
	public void CreateStudent(StudentBO studentBo);
	public  void ViewStudent(int StudentId);
	public List<StudentBO> ListStudent();
	public  int login(LoginBO login);
	public  int updateStudent(StudentBO studentBo);
	public  int deleteStudent(int StudentId);

}
