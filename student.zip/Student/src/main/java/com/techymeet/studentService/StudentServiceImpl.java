package com.techymeet.studentService;

import java.util.List;

import com.techymeet.studentBO.LoginBO;
import com.techymeet.studentBO.StudentBO;
import com.techymeet.studentDao.StudentDao;
import com.techymeet.studentDao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService{

	StudentDao studentDao = new StudentDaoImpl();
	@Override
	public void CreateStudent(StudentBO studentBo) {
		
		int status = studentDao.CreateStudent(studentBo);
		if(0 < status) {
			System.out.println("Student Has Been Created Sucessfully!");
			}
			else {
				System.out.println("Student Creation failed");
			}
	}
	@Override
	public void ViewStudent(int StudentId) {
    studentDao.viewStudent(StudentId);	
	}

	@Override
	public List<StudentBO> ListStudent() {
		return studentDao.listStudent();
	}

	@Override
	public int updateStudent(StudentBO studentBo) {
		
		return studentDao.updateStudent(studentBo);
	}

	@Override
	public int deleteStudent(int StudentId) {
		return studentDao.deleteStudent(StudentId);
	}

	@Override
	public int login(LoginBO login) {
	return studentDao.login(login);		
	}

}
