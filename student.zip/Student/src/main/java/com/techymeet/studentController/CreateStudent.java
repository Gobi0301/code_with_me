package com.techymeet.studentController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techymeet.studentBO.StudentBO;
import com.techymeet.studentService.StudentService;
import com.techymeet.studentService.StudentServiceImpl;
@WebServlet("/CreateStudent")
public class CreateStudent extends HttpServlet{
	
	
	public CreateStudent() {
		super();
	}	
	
	public void doget() {
		
	}
	
	public void dopost(HttpServletRequest req,HttpServletResponse res) throws IOException {
		
		StudentBO studentBo = new StudentBO();
		
		String StudentId = req.getParameter("StudentId");
		studentBo.setStudentId(Integer.parseInt(StudentId));
		String StudentName = req.getParameter("StudentName");
		studentBo.setStudentName(StudentName);
		String password = req.getParameter("password");
		studentBo.setPassword(password);
		String mobileNo = req.getParameter("mobileNo");
		studentBo.setMobileNo(Long.parseLong(mobileNo));
		String location = req.getParameter("location");
		studentBo.setLocation(location);
		StudentService service = new StudentServiceImpl();
		try {
			service.CreateStudent(studentBo);
		} catch (Exception e) {
        e.printStackTrace();		}
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		
		pw.println("Student Created Successfully....!");
		//pw.println("<a href ='createStudent.html'>StudentCreation </a>");
	}

}
