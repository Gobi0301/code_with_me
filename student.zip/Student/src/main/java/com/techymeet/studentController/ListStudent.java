package com.techymeet.studentController;

import javax.servlet.http.HttpServlet;

public class ListStudent extends HttpServlet{

	public  ListStudent() {
		super();
	}
}
