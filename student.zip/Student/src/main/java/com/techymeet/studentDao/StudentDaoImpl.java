package com.techymeet.studentDao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.techymeet.studentBO.LoginBO;
import com.techymeet.studentBO.StudentBO;
import com.techymeet.studentDb.DatabaseConnection;

public class StudentDaoImpl implements StudentDao{

	
	DatabaseConnection db= new DatabaseConnection();
	@Override
	public int CreateStudent(StudentBO studentBo) {
    int status = 0;
    try {
		Connection con = db.getConnection();
		String query = "insert in to Student(StudentId,StudentName,password,mobileNo,location) values(?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(query); 
		ps.setInt(1, studentBo.getStudentId());
		ps.setString(2,studentBo.getStudentName());
		ps.setString(3, studentBo.getPassword());
		ps.setLong(4, studentBo.getMobileNo());
		ps.setString(5, studentBo.getLocation());
		status = ps.executeUpdate();
		con.close();
		} catch (Exception e) {
          e.printStackTrace();	}		
		return status;
	}
	@Override
	public StudentBO viewStudent(int StudentId) {
      StudentBO res = null;
      try {
		Connection con = db.getConnection();
        java.sql.Statement ps = con.createStatement();
		String query= "select * from Student where StudentId="+StudentId;
		ResultSet rs= ps.executeQuery(query);
		while(rs.next()) {
			res = new StudentBO();
			res.setStudentId(rs.getInt("StudentId"));
			res.setStudentName(rs.getString("StudentName"));
		    res.setPassword(rs.getString("password"));
		    res.setMobileNo(rs.getLong("mobileNO"));
		    res.setLocation(rs.getString("location"));
		}
		ps.close();
		con.close();
		
	} catch (Exception e) {
      e.printStackTrace();	}
		
		return res;
	}

	@Override
	public List<StudentBO> listStudent() {
    StudentBO res = null;
    List<StudentBO> studentList = new ArrayList<StudentBO>();
    try {
    	Connection con = db.getConnection();
        java.sql.Statement ps = con.createStatement();
		String query= "select * from Student ";
		ResultSet rs= ps.executeQuery(query);
		while(rs.next()) {
			res = new StudentBO();
			res.setStudentId(rs.getInt("StudentId"));
			res.setStudentName(rs.getString("StudentName"));
		    res.setPassword(rs.getString("password"));
		    res.setMobileNo(rs.getLong("mobileNO"));
		    res.setLocation(rs.getString("location"));
		    studentList.add(res);
		}
		ps.close();
		con.close();		
	} catch (Exception e) {
     e.printStackTrace();
	}
		return studentList;
	}
	@Override
	public int updateStudent(StudentBO studentBo) {
    int status = 0;
    try {
		Connection con = db.getConnection();
		String query = "update Student set StudentId=?,StudentName=?,password=?,mobileNo=?,location=? where StudentId =?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, studentBo.getStudentId());
		ps.setString(2,studentBo.getStudentName());
		ps.setString(3, studentBo.getPassword());
		ps.setLong(4, studentBo.getMobileNo());
		ps.setString(5, studentBo.getLocation());
        ps.setInt(6, studentBo.getStudentId());
		status = ps.executeUpdate();
		con.close();
  
    } catch (Exception e) {
      e.printStackTrace();
    }
		return status;
	}

	public int deleteStudent(int StudentId) {

		int id = 0;
		try {
			Connection con = db.getConnection();
			String query = "Delete from Student where StudentId=?";
	        PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1,StudentId);
            id= ps.executeUpdate();
            ps.close();
            con.close();
		} catch (Exception e) {
          e.printStackTrace();
		}
		return id;
	}
	@Override
	public int login(LoginBO login) {
		int status = 0;
		try {
			Connection con = db.getConnection();
			String sql = "insert in to login(userName,password)values(?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,login.getUserName());
			ps.setString(2, login.getPassword());
			status = ps.executeUpdate();
			ps.close();
			con.close();
		} catch (Exception e) {
          e.printStackTrace();
		}
		return status;
	}
}
