package com.techymeet.studentDao;

import java.util.List;

import com.techymeet.studentBO.LoginBO;
import com.techymeet.studentBO.StudentBO;

public interface StudentDao {
	
	int CreateStudent(StudentBO studentBo);
	StudentBO viewStudent(int StudentId);	
	List<StudentBO> listStudent();	
	int updateStudent(StudentBO studentBo);	
    int login(LoginBO login);
	int deleteStudent(int StudentId);

	
	

}
