package com.techymeet.office.bo;

public class ProductBo {

	private int productId;
	   private String productName;
	   private String brand;
	   private	double price;
	   private	int quantity; 
	   private boolean warranty;
		
	   public int getproductId() {
		   return productId;
	   }
	   public void setproductId(int productId) {
		   this.productId = productId;
	   }
	   public String getproductName() {
		   return productName;
	   }
	   public void setproductName(String productName) {
		   this.productName = productName;
	   }
	   public String getbrand() {
		   return brand;
	   }
	   public void setbrand(String brand) {
		   this.brand = brand;
	   }
	   public double getprice() {
		   return price;
	   }
	   public void setprice(double price) {
		   this.price = price;
	   }
	   public int getquantity() {
		   return quantity;
	   }
	   public void setquantity(int quantity) {
		   this.quantity = quantity;
	   }
	   public boolean getwarranty() {
		   return warranty;
	   }
	   public void setwarranty(boolean warranty) {
		   this.warranty = warranty;
	   }
}
