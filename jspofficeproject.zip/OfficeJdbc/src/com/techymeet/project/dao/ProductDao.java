package com.techymeet.project.dao;
import java.util.ArrayList;

import com.techymeet.office.bo.ProductBo;
public interface ProductDao {

	int createProduct(ProductBo productBo);
	ArrayList<ProductBo> listProduct();
	ProductBo viewProduct(int productId);
	int editProducct(ProductBo productBo);
	int deleteProduct(int productId);
	ArrayList<ProductBo> searchProduct(ProductBo productBo);
}
