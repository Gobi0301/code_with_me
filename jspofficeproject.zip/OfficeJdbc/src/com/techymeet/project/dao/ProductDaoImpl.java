package com.techymeet.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import com.techymeet.office.bo.ProductBo;
import com.techymeet.office.db.DatabaseConnection;


public class ProductDaoImpl implements ProductDao{

	@Override
	public int createProduct(ProductBo productBo) {
		// TODO Auto-generated method stub
		int status =0;
		try {
			Connection con = DatabaseConnection.createConnection();
			String query = "insert into product(product_id,product_name,product_brand,product_price,product_quantity,product_warranty) values (?,?,?,?,?,?)";
		    PreparedStatement ps = con.prepareStatement(query);
		    ps.setInt(1, productBo.getproductId());
		    ps.setString(2, productBo.getproductName());
		    ps.setString(3, productBo.getbrand());
		    ps.setDouble(4, productBo.getprice());
		    ps.setInt(5, productBo.getquantity());
		    ps.setBoolean(6, productBo.getwarranty());	
		    status = ps.executeUpdate();
		    con.close();
		    
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return status;
		
	}

	@Override
	public ArrayList<ProductBo> listProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductBo viewProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int editProducct(ProductBo productBo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<ProductBo> searchProduct(ProductBo productBo) {
		// TODO Auto-generated method stub
		return null;
	}

}
