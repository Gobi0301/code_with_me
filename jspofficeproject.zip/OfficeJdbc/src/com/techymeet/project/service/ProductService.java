package com.techymeet.project.service;

public interface ProductService {

	
	void createProduct();

	void updateProduct();

	void listProduct();

	void viewProduct();

	void deleteProduct();

	void searchProduct();
	
}
