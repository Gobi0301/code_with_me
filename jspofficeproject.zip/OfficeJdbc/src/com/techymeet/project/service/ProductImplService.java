package com.techymeet.project.service;

import java.util.Scanner;

import com.techymeet.office.bo.ProductBo;
import com.techymeet.project.dao.ProductDao;
import com.techymeet.project.dao.ProductDaoImpl;

public class ProductImplService implements ProductService {

	@Override
	public void createProduct() {
		// TODO Auto-generated method stub
		ProductDao productdao = new ProductDaoImpl();
		Scanner scannerObj = new Scanner(System.in);
		ProductBo productBo = new ProductBo();
			
		System.out.println("Please Enter ProductId:");
		int productId=0;
		boolean productIdStatus = true;
		try {
			while (productIdStatus) {    
				productId = scannerObj.nextInt();
				if (0 < productId) {     
					productBo.setproductId(productId);
					productIdStatus = false;

				} else {
					System.out.println("Please enter valid productId:");

				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		scannerObj.nextLine();
		System.out.println("Please Enter ProductName:");
		String productName=null;
		boolean productNameStatus = true;
		try {
			while (productNameStatus) {    
				productName = scannerObj.nextLine();
				if (!productName.isEmpty()) {     
					productBo.setproductName(productName);
					productNameStatus = false;

				} else {
					System.out.println("Please enter valid productName:");

				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Please Enter ProductBrand:");
		String productBrand=null;
		boolean productBrandStatus = true;
		try {
			while (productBrandStatus) {    
				productBrand = scannerObj.nextLine();
				if (!productBrand.isEmpty()) {     
					productBo.setbrand(productBrand);
					productBrandStatus = false;

				} else {
					System.out.println("Please enter valid ProductBrand:");

				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Please Enter ProductPrice:");
		double productPrice=0;
		boolean productPriceStatus = true;
		try {
			while (productPriceStatus) {    
				productPrice = scannerObj.nextDouble();
				if (0 < productPrice) {     
					productBo.setprice(productPrice);
					productPriceStatus = false;

				} else {
					System.out.println("Please enter valid productPrice:");

				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Please Enter ProductQuantity:");
		int productQuantity=0;
		boolean productQunatityStatus = true;
		try {
			while (productQunatityStatus) {    
				productQuantity = scannerObj.nextInt();
				if (0 < productQuantity) {     
					productBo.setquantity(productQuantity);
					productQunatityStatus = false;

				} else {
					System.out.println("Please enter valid productQuantity:");

				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Please Enter ProductWarranty:");
		boolean productWarranty= true;
		boolean productWarrantyStatus = true;
		try {
			while (productWarrantyStatus) {    
				//productWarranty = scannerObj.nextBoolean();
				scannerObj.nextLine();
			String warranty = scannerObj.nextLine();
			  if(warranty.equalsIgnoreCase("yes")) {
				  productBo.setwarranty(true);
				  productWarrantyStatus = false;
			  }
			  else if(warranty.equalsIgnoreCase("No")) {
				  productBo.setwarranty(false);
				  productWarrantyStatus = false;
			  }
				/*if (productWarranty) {     
					productBo.setwarranty(productWarranty);
					productWarrantyStatus = false;

				} */else {
					System.out.println("Please enter valid productWarranty:");

				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		int status = productdao.createProduct(productBo);
		if(0<status) {
		System.out.println("Product Has Been Created Sucessfully!");
		}
		else {
			System.out.println("Product Creation failed");
		}
		
	}

	@Override
	public void updateProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void listProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchProduct() {
		// TODO Auto-generated method stub
		
	}

}
