package com.techymeet.project.controller;

import java.util.Scanner;

import com.techymeet.project.service.ProductImplService;
import com.techymeet.project.service.ProductService;

public class officeController {

	public static void main(String[] args) {
	
		Scanner scanner=new Scanner(System.in);
		ProductService productservice = new ProductImplService();
		boolean status=true;
		while(status) {
			
			System.out.println("Please choose any menu option: ");
			System.out.println("1. Create Product ");
			System.out.println("2. List Product ");
			System.out.println("3. Update Product ");
			System.out.println("4. View Product ");
			System.out.println("5. Delete Product ");
			System.out.println("6.search Product");
			System.out.println("7. Logout");

			int option=scanner.nextInt();
			
			switch(option) {
			
			case 1:
				productservice.createProduct();
				break;
			default:
				System.out.println("Please select valid option!");
			}
		
	}
	}
}
